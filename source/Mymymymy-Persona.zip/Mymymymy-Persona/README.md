Mymymymy-Persona!
=================

An AJAX authentication system built around Mozilla Persona.

Mymymymy Persona! was designed to easily drop-in to existing web applications.


External resources
==================

For more information, please visit:

http://www.goodsteve.co/Mymymymy-Persona/index.html

https://developer.mozilla.org/en-US/docs/Persona/Why_Persona

https://developer.mozilla.org/en-US/docs/Persona


Rgds,
Steve
